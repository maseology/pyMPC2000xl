pympc1000
=========

Python module for loading, editing, and exporting Akai MPC 1000 .pgm files.


Stephen Norum
stephen@mybunnyhug.org
http://www.mybunnyhug.org
