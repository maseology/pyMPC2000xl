'load, edit, and export Akai MPC 1000 program file data'

# Re-import these for convenience
from mpc1k import *

__all__ = (mpc1k.__all__)
